README  

DbVisualizer - The Universal Database Tool

Open doc/index.html in a web browser for more information.

Latest information about DbVisualizer, documentation, FAQ and
support is available at http://www.dbvis.com
