This directory is either empty or contains directories with JDBC drivers.
